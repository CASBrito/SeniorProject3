import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class EditarMedicacaoScreen {

	private JFrame frmEditarMedicao;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarMedicacaoScreen window = new EditarMedicacaoScreen();
					window.frmEditarMedicao.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EditarMedicacaoScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEditarMedicao = new JFrame();
		frmEditarMedicao.setTitle("Editar Medicação");
		frmEditarMedicao.setBounds(100, 100, 727, 411);
		frmEditarMedicao.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmEditarMedicao.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Voltar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEditarMedicao.setVisible(false);
				MenuPrincipalScreen.main(null);
			}
		});
		btnNewButton_1.setBounds(10, 10, 93, 27);
		frmEditarMedicao.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Medicação:");
		lblNewLabel.setBounds(32, 68, 80, 20);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		frmEditarMedicao.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Dias da Semana");
		lblNewLabel_1.setBounds(61, 134, 109, 20);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		frmEditarMedicao.getContentPane().add(lblNewLabel_1);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Segunda");
		chckbxNewCheckBox.setBounds(61, 170, 93, 21);
		chckbxNewCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("Terça");
		chckbxNewCheckBox_1.setBounds(61, 193, 93, 21);
		chckbxNewCheckBox_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_1);
		
		JCheckBox chckbxNewCheckBox_2 = new JCheckBox("Quarta");
		chckbxNewCheckBox_2.setBounds(61, 216, 93, 21);
		chckbxNewCheckBox_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_2);
		
		JCheckBox chckbxNewCheckBox_3 = new JCheckBox("Quinta");
		chckbxNewCheckBox_3.setBounds(61, 239, 93, 21);
		chckbxNewCheckBox_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_3);
		
		JCheckBox chckbxNewCheckBox_4 = new JCheckBox("Sexta");
		chckbxNewCheckBox_4.setBounds(61, 262, 93, 21);
		chckbxNewCheckBox_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_4);
		
		JCheckBox chckbxNewCheckBox_5 = new JCheckBox("Sábado");
		chckbxNewCheckBox_5.setBounds(61, 285, 93, 21);
		chckbxNewCheckBox_5.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_5);
		
		JCheckBox chckbxNewCheckBox_6 = new JCheckBox("Domingo");
		chckbxNewCheckBox_6.setBounds(61, 308, 93, 21);
		chckbxNewCheckBox_6.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_6);
		
		JPanel panel = new JPanel();
		panel.setBounds(46, 117, 163, 228);
		frmEditarMedicao.getContentPane().add(panel);
		
		JCheckBox chckbxNewCheckBox_7 = new JCheckBox("Jejum");
		chckbxNewCheckBox_7.setBounds(271, 170, 93, 21);
		chckbxNewCheckBox_7.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_7);
		
		JCheckBox chckbxNewCheckBox_8 = new JCheckBox("Pequeno Almoço");
		chckbxNewCheckBox_8.setBounds(271, 193, 125, 21);
		chckbxNewCheckBox_8.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_8);
		
		JCheckBox chckbxNewCheckBox_9 = new JCheckBox("Almoço");
		chckbxNewCheckBox_9.setBounds(271, 216, 93, 21);
		chckbxNewCheckBox_9.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_9);
		
		JCheckBox chckbxNewCheckBox_10 = new JCheckBox("Jantar");
		chckbxNewCheckBox_10.setBounds(271, 239, 93, 21);
		chckbxNewCheckBox_10.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(chckbxNewCheckBox_10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(440, 172, 45, 19);
		textField_1.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("QT: ");
		lblNewLabel_2_1.setBounds(409, 198, 45, 13);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2 = new JLabel("QT: ");
		lblNewLabel_2.setBounds(409, 175, 45, 13);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(440, 195, 45, 19);
		textField_2.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("QT: ");
		lblNewLabel_2_3.setBounds(409, 244, 45, 13);
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_2 = new JLabel("QT: ");
		lblNewLabel_2_2.setBounds(409, 221, 45, 13);
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_2_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(440, 218, 45, 19);
		textField_3.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setBounds(440, 241, 45, 19);
		textField_4.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_4);
		
		JLabel lblNewLabel_3_1_1_1 = new JLabel("Notas: ");
		lblNewLabel_3_1_1_1.setBounds(495, 244, 45, 13);
		lblNewLabel_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_3_1_1_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Notas: ");
		lblNewLabel_3_1_1.setBounds(495, 221, 45, 13);
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("Notas: ");
		lblNewLabel_3_1.setBounds(495, 198, 45, 13);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3 = new JLabel("Notas: ");
		lblNewLabel_3.setBounds(495, 175, 45, 13);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmEditarMedicao.getContentPane().add(lblNewLabel_3);
		
		textField_5 = new JTextField();
		textField_5.setBounds(533, 172, 139, 19);
		textField_5.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setBounds(533, 195, 139, 19);
		textField_6.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setBounds(533, 218, 139, 19);
		textField_7.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setBounds(533, 241, 139, 19);
		textField_8.setColumns(10);
		frmEditarMedicao.getContentPane().add(textField_8);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEditarMedicao.setVisible(false);
				MenuPrincipalScreen.main(null);
			}
		});
		btnEditar.setBounds(533, 319, 125, 37);
		btnEditar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		frmEditarMedicao.getContentPane().add(btnEditar);
		
		JButton btnNewButton_1_1 = new JButton("Logout");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEditarMedicao.setVisible(false);
				StartScreen.main(null);
			}
		});
		btnNewButton_1_1.setBounds(612, 13, 93, 27);
		frmEditarMedicao.getContentPane().add(btnNewButton_1_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(258, 155, 431, 128);
		frmEditarMedicao.getContentPane().add(panel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(122, 70, 567, 21);
		frmEditarMedicao.getContentPane().add(comboBox);
	}
}
