import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JList;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.ListSelectionModel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;

public class VerificarMedicacaoScreen {

	private JFrame frmVerificarMedicao;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VerificarMedicacaoScreen window = new VerificarMedicacaoScreen();
					window.frmVerificarMedicao.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VerificarMedicacaoScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmVerificarMedicao = new JFrame();
		frmVerificarMedicao.setTitle("Verificar Medicação");
		frmVerificarMedicao.setBounds(100, 100, 311, 322);
		frmVerificarMedicao.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmVerificarMedicao.getContentPane().setLayout(null);
		
		JList list = new JList();
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		list.setForeground(Color.DARK_GRAY);
		list.setBackground(Color.WHITE);
		list.setBounds(136, 129, 128, 53);
		frmVerificarMedicao.getContentPane().add(list);
		
		JLabel lblNewLabel = new JLabel("Medicação");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(27, 126, 82, 20);
		frmVerificarMedicao.getContentPane().add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(136, 99, 128, 20);
		frmVerificarMedicao.getContentPane().add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Altura do Dia:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(27, 95, 99, 24);
		frmVerificarMedicao.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Quantidade:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(27, 194, 99, 20);
		frmVerificarMedicao.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(136, 192, 128, 24);
		frmVerificarMedicao.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(136, 230, 128, 24);
		frmVerificarMedicao.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Notas:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(27, 235, 82, 13);
		frmVerificarMedicao.getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("Voltar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmVerificarMedicao.setVisible(false);
				MenuPrincipalScreen.main(null);
			}
		});
		btnNewButton.setBounds(10, 10, 99, 24);
		frmVerificarMedicao.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Logout");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmVerificarMedicao.setVisible(false);
				StartScreen.main(null);
			}
		});
		btnNewButton_1.setBounds(184, 10, 99, 24);
		frmVerificarMedicao.getContentPane().add(btnNewButton_1);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(27, 55, 237, 30);
		frmVerificarMedicao.getContentPane().add(dateChooser);
	}
}
