import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class RegisterScreen {

	private JFrame frmRegister;
	private JPasswordField passwordField;
	private JTextField textField;
	private JTextField txtDdmmaaaa;
	private JTextField textField_1;
	
	private static DataBaseConnection dbConnection = new DataBaseConnection();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		dbConnection.ligarBd();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterScreen window = new RegisterScreen();
					window.frmRegister.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegisterScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmRegister = new JFrame();
		frmRegister.setTitle("Register");
		frmRegister.setBounds(100, 100, 474, 325);
		frmRegister.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmRegister.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(52, 43, 81, 29);
		frmRegister.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(52, 123, 81, 29);
		frmRegister.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password: ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(52, 162, 107, 29);
		frmRegister.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Data Nascimento: ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(52, 82, 132, 29);
		frmRegister.getContentPane().add(lblNewLabel_3);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(182, 164, 228, 29);
		frmRegister.getContentPane().add(passwordField);
		
		textField = new JTextField();
		textField.setBounds(182, 125, 228, 29);
		frmRegister.getContentPane().add(textField);
		textField.setColumns(10);
		
		txtDdmmaaaa = new JTextField();
		txtDdmmaaaa.setBounds(182, 81, 120, 30);
		frmRegister.getContentPane().add(txtDdmmaaaa);
		txtDdmmaaaa.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("AAAA-MM-DD");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(312, 85, 98, 23);
		frmRegister.getContentPane().add(lblNewLabel_4);
		
		textField_1 = new JTextField();
		textField_1.setBounds(182, 40, 228, 29);
		frmRegister.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("Resgistar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection connection = dbConnection.getConnection();
				String nome = textField_1.getText();
				String dataNasc = txtDdmmaaaa.getText();
				String email = textField.getText();
				String pass = new String(passwordField.getPassword());
				
				try {
					Statement statement = connection.createStatement();
					String query = "Insert into idoso(Nome, DataNascimento, Email, Password) values ('" + nome + "', '" + dataNasc + "', '" + email + "', '" + pass + "')";
					statement.executeUpdate(query);
					
					frmRegister.setVisible(false);
					MenuPrincipalScreen.main(null);
				} catch (SQLException e1) {
					System.out.println(e1);
				}
				
			}
		});
		btnNewButton.setBounds(197, 215, 105, 36);
		frmRegister.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Voltar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmRegister.setVisible(false);
				StartScreen.main(null);
			}
		});
		btnNewButton_1.setBounds(10, 10, 85, 29);
		frmRegister.getContentPane().add(btnNewButton_1);
	}
	

}
