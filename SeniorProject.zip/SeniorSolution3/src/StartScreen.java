import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StartScreen {

	private JFrame frmMedicationManagement;
	private static DataBaseConnection dbConnection = new DataBaseConnection();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		/*dbConnection.ligarBd();*/
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartScreen window = new StartScreen();
					window.frmMedicationManagement.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Create the application.
	 */
	public StartScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMedicationManagement = new JFrame();
		frmMedicationManagement.setTitle("Medication Management");
		frmMedicationManagement.getContentPane().setBackground(new Color(0, 128, 255));
		frmMedicationManagement.setBounds(100, 100, 554, 441);
		frmMedicationManagement.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMedicationManagement.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Login");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMedicationManagement.setVisible(false);
				LoginScreen.main(null);
			}
		});
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(108, 286, 130, 48);
		frmMedicationManagement.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Registar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMedicationManagement.setVisible(false);
				RegisterScreen.main(null);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(297, 286, 130, 48);
		frmMedicationManagement.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\gfgma\\Downloads\\Background_startingscreen.JPG"));
		lblNewLabel.setBounds(0, 0, 581, 547);
		frmMedicationManagement.getContentPane().add(lblNewLabel);
	}
}
