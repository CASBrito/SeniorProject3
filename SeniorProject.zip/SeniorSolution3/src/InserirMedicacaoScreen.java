import java.awt.EventQueue;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InserirMedicacaoScreen {

	private JFrame frmInserirMedicao;
	private JTextField textMedicacao;
	private JTextField qtJejum;
	private JTextField qtPA;
	private JTextField qtAlmoco;
	private JTextField qtJantar;
	private JTextField notaJejum;
	private JTextField notaPA;
	private JTextField notaAlmoco;
	private JTextField notaJantar;
	
	private static DataBaseConnection dbConnection = new DataBaseConnection();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		dbConnection.ligarBd();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InserirMedicacaoScreen window = new InserirMedicacaoScreen();
					window.frmInserirMedicao.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public InserirMedicacaoScreen() {
		initialize();
	}
	
	private void InserirMedicacao() {
		Connection connection = dbConnection.getConnection();
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmInserirMedicao = new JFrame();
		frmInserirMedicao.setTitle("Inserir Medicação");
		frmInserirMedicao.setBounds(100, 100, 729, 418);
		frmInserirMedicao.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmInserirMedicao.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Medicação:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(32, 68, 80, 20);
		frmInserirMedicao.getContentPane().add(lblNewLabel);
		
		textMedicacao = new JTextField();
		textMedicacao.setBounds(122, 67, 560, 27);
		frmInserirMedicao.getContentPane().add(textMedicacao);
		textMedicacao.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Dias da Semana");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(61, 134, 109, 20);
		frmInserirMedicao.getContentPane().add(lblNewLabel_1);
		
		JCheckBox checkboxSegunda = new JCheckBox("Segunda");
		checkboxSegunda.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxSegunda.setBounds(61, 170, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxSegunda);
		
		JCheckBox checkboxTerca = new JCheckBox("Terça");
		checkboxTerca.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxTerca.setBounds(61, 193, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxTerca);
		
		JCheckBox checkboxQuarta = new JCheckBox("Quarta");
		checkboxQuarta.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxQuarta.setBounds(61, 216, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxQuarta);
		
		JCheckBox checkboxQuinta = new JCheckBox("Quinta");
		checkboxQuinta.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxQuinta.setBounds(61, 239, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxQuinta);
		
		JCheckBox checkboxSexta = new JCheckBox("Sexta");
		checkboxSexta.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxSexta.setBounds(61, 262, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxSexta);
		
		JCheckBox checkboxSabado = new JCheckBox("Sábado");
		checkboxSabado.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxSabado.setBounds(61, 285, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxSabado);
		
		JCheckBox checkboxDomingo = new JCheckBox("Domingo");
		checkboxDomingo.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxDomingo.setBounds(61, 308, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxDomingo);
		
		JPanel panel = new JPanel();
		panel.setBounds(46, 117, 163, 228);
		frmInserirMedicao.getContentPane().add(panel);
		
		final JCheckBox checkboxJejum = new JCheckBox("Jejum");
		checkboxJejum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checkboxJejum.isSelected()) {
					qtJejum.setEditable(true);
					notaJejum.setEditable(true);
				}else {
					qtJejum.setEditable(false);
					qtJejum.setText(null);
					notaJejum.setEditable(false);
					notaJejum.setText(null);
				}
			}
		});
		checkboxJejum.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxJejum.setBounds(271, 170, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxJejum);
		
		final JCheckBox checkboxPA = new JCheckBox("Pequeno Almoço");
		checkboxPA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checkboxPA.isSelected()) {
					qtPA.setEditable(true);
					notaPA.setEditable(true);
				}else {
					qtPA.setEditable(false);
					qtPA.setText(null);
					notaPA.setEditable(false);
					notaPA.setText(null);
				}
			}
		});
		checkboxPA.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxPA.setBounds(271, 193, 125, 21);
		frmInserirMedicao.getContentPane().add(checkboxPA);
		
		final JCheckBox checkboxAlmoco = new JCheckBox("Almoço");
		checkboxAlmoco.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checkboxAlmoco.isSelected()) {
					qtAlmoco.setEditable(true);
					notaAlmoco.setEditable(true);
				}else {
					qtAlmoco.setEditable(false);
					qtAlmoco.setText(null);
					notaAlmoco.setEditable(false);
					notaAlmoco.setText(null);
				}
			}
		});
		checkboxAlmoco.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxAlmoco.setBounds(271, 216, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxAlmoco);
		
		final JCheckBox checkboxJantar = new JCheckBox("Jantar");
		checkboxJantar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checkboxJantar.isSelected()) {
					qtJantar.setEditable(true);
					notaJantar.setEditable(true);
				}else {
					qtJantar.setEditable(false);
					qtJantar.setText(null);
					notaJantar.setEditable(false);
					notaJantar.setText(null);
				}
			}
		});
		checkboxJantar.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkboxJantar.setBounds(271, 239, 93, 21);
		frmInserirMedicao.getContentPane().add(checkboxJantar);
		
		JLabel lblNewLabel_2 = new JLabel("QT: ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(409, 175, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("QT: ");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1.setBounds(409, 198, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("QT: ");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_2.setBounds(409, 221, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("QT: ");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_3.setBounds(409, 244, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_2_3);
		
		qtJejum = new JTextField();
		qtJejum.setEditable(false);
		qtJejum.setBounds(440, 172, 45, 19);
		frmInserirMedicao.getContentPane().add(qtJejum);
		qtJejum.setColumns(10);
		
		qtPA = new JTextField();
		qtPA.setEditable(false);
		qtPA.setColumns(10);
		qtPA.setBounds(440, 195, 45, 19);
		frmInserirMedicao.getContentPane().add(qtPA);
		
		qtAlmoco = new JTextField();
		qtAlmoco.setEditable(false);
		qtAlmoco.setColumns(10);
		qtAlmoco.setBounds(440, 218, 45, 19);
		frmInserirMedicao.getContentPane().add(qtAlmoco);
		
		qtJantar = new JTextField();
		qtJantar.setEditable(false);
		qtJantar.setColumns(10);
		qtJantar.setBounds(440, 241, 45, 19);
		frmInserirMedicao.getContentPane().add(qtJantar);
		
		JLabel lblNewLabel_3 = new JLabel("Notas: ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(495, 175, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Notas: ");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_1.setBounds(495, 198, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Notas: ");
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_1_1.setBounds(495, 221, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_3_1_1_1 = new JLabel("Notas: ");
		lblNewLabel_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_1_1_1.setBounds(495, 244, 45, 13);
		frmInserirMedicao.getContentPane().add(lblNewLabel_3_1_1_1);
		
		notaJejum = new JTextField();
		notaJejum.setEditable(false);
		notaJejum.setBounds(533, 172, 139, 19);
		frmInserirMedicao.getContentPane().add(notaJejum);
		notaJejum.setColumns(10);
		
		notaPA = new JTextField();
		notaPA.setEditable(false);
		notaPA.setColumns(10);
		notaPA.setBounds(533, 195, 139, 19);
		frmInserirMedicao.getContentPane().add(notaPA);
		
		notaAlmoco = new JTextField();
		notaAlmoco.setEditable(false);
		notaAlmoco.setColumns(10);
		notaAlmoco.setBounds(533, 218, 139, 19);
		frmInserirMedicao.getContentPane().add(notaAlmoco);
		
		notaJantar = new JTextField();
		notaJantar.setEditable(false);
		notaJantar.setColumns(10);
		notaJantar.setBounds(533, 241, 139, 19);
		frmInserirMedicao.getContentPane().add(notaJantar);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(260, 154, 422, 129);
		frmInserirMedicao.getContentPane().add(panel_1);
		
		JButton buttonInserir = new JButton("Inserir");
		buttonInserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInserirMedicao.setVisible(false);
				MenuPrincipalScreen.main(null);
			}
		});
		buttonInserir.setFont(new Font("Tahoma", Font.PLAIN, 15));
		buttonInserir.setBounds(409, 319, 118, 37);
		frmInserirMedicao.getContentPane().add(buttonInserir);
		
		JButton buttonInserirM = new JButton("Inserir Mais");
		buttonInserirM.setFont(new Font("Tahoma", Font.PLAIN, 15));
		buttonInserirM.setBounds(533, 319, 125, 37);
		frmInserirMedicao.getContentPane().add(buttonInserirM);
		
		JButton buttonVoltar = new JButton("Voltar");
		buttonVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInserirMedicao.setVisible(false);
				MenuPrincipalScreen.main(null);
			}
		});
		buttonVoltar.setBounds(10, 10, 93, 27);
		frmInserirMedicao.getContentPane().add(buttonVoltar);
		
		JButton buttonLogout = new JButton("Logout");
		buttonLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInserirMedicao.setVisible(false);
				StartScreen.main(null);
			}
		});
		buttonLogout.setBounds(612, 13, 93, 27);
		frmInserirMedicao.getContentPane().add(buttonLogout);
		
	    /*Criar Matrice de checkboxes */
		
		/*JCheckBox alturaDia[][] = { {checkboxSegunda, checkboxTerca, checkboxQuarta, checkboxQuinta, checkboxSexta, checkboxSabado, checkboxDomingo},
									{checkboxJejum, checkboxPA, checkboxAlmoco, checkboxJantar} };*/
		};
		
		/*backup*/
		/*List<ArrayList<JCheckBox>> listaDiaSemana = new ArrayList<ArrayList<JCheckBox>>();
		
		for(int i=0; i < 7; i++) {
			listaDiaSemana.add(new ArrayList<JCheckBox>());
			for(int j = 0; j < 4; j++) {
				listaDiaSemana.get(i).add(alturaDia[j]);
			}
		}*/

		
	}
