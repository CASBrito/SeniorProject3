import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataBaseConnection {
	
	private String url = "jdbc:mysql://localhost:3306/medicationmanagement";
	private String username = "root";
	private String password = "carlosbrito543990";
	private Connection connection;
	
	public void ligarBd() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			connection = DriverManager.getConnection(url, username, password);
			
			/*teste de connection*/
			/*Statement statement = connection.createStatement();
			
			ResultSet resultSet = statement.executeQuery("SELECT * FROM idoso");
			
			while (resultSet.next()) {
				System.out.println(resultSet.getString(2));
			}*/
		}
		catch (Exception e) {
			System.out.println(e);
			
		}
	}
	
	public Connection getConnection() {
		return connection;
	}
}


