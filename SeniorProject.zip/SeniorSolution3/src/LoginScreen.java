import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginScreen {

	private JFrame frmLogin;
	private JTextField textField;
	private JPasswordField passwordField;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	
	private static DataBaseConnection dbConnection = new DataBaseConnection();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		dbConnection.ligarBd();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginScreen window = new LoginScreen();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setTitle("Login");
		frmLogin.setBounds(100, 100, 426, 287);
		frmLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Email:  ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(71, 62, 99, 34);
		frmLogin.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(71, 106, 99, 34);
		frmLogin.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(155, 68, 220, 28);
		frmLogin.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(155, 112, 220, 28);
		frmLogin.getContentPane().add(passwordField);
		
		btnNewButton = new JButton("Entrar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection connection = dbConnection.getConnection();
				String email = textField.getText();
				String pass = new String(passwordField.getPassword());
				boolean check = false;
				
				try {
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery("select * from idoso");
					
					while (resultSet.next()){
						if(email.equals(resultSet.getString(4)) && pass.equals(resultSet.getString(5))) {				
							check = true;
							break;
						}
					}
										
					if(check) {
						frmLogin.setVisible(false);
						MenuPrincipalScreen.main(null);
					}else {
						JOptionPane.showMessageDialog(null,"Credenciais erradas!");
					}
				} catch (SQLException e1) {
					System.out.println(e1);
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(135, 171, 104, 39);
		frmLogin.getContentPane().add(btnNewButton);
		
		btnNewButton_1 = new JButton("Voltar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmLogin.setVisible(false);
				StartScreen.main(null);
			}
		});
		btnNewButton_1.setBounds(10, 10, 85, 28);
		frmLogin.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(155, 38, 142, 20);
		frmLogin.getContentPane().add(lblNewLabel_2);
	}
}
